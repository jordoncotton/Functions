#include <iostream>
#include <string>

// Jordon Cotton is awesome and cool
int print(std::string input)
{
	std::cout << input;
	return 0;
}


bool IsmultipleofThree(int value)
{
	return value % 3 == 0;
}

void PrintValuesTo10()
{
	for (int i = 0; i <= 10; i++)
	{
		std::cout << i;
	}
	std::cout << std::endl;
	system("pause");
}
 
void PrintValuesBetween(int low, int high)
{
	for (int i = low + 1; i < high; high++)
	{
		std::cout << i;
	}
	std::cout << std::endl;
	system("pause");
}
//
//Create a function that will take in a array and the length of the array
//The function will return the sum of all the values in the array
int ArraySum(int arr[], int size)

{
	
}







//create a function that will reverse the values in the array passed in.
//you will neeed to pass in a array and the size of the array as arguments.
//cannot use a second array
void RevArray(int arr[], int size)
{

}



int main()
{
	ArraySum ()
}
